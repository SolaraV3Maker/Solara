If you encounter any error, try to do this:

1. Turn off the antivirus

2. Turn on the VPN

3. Restart the PC


If none of the methods helped, try to find a solution to the problem yourself. The methods described above will help in most cases.
